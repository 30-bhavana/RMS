package com.recipeapp.controller;

import com.recipeapp.model.Recipe;
import com.recipeapp.service.RecipeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@RequestMapping("/api/recipes")
public class RecipeController {

    private final RecipeService recipeService;

    @Autowired
    public RecipeController(RecipeService recipeService) {
        this.recipeService = recipeService;
    }

    private String currentEmail(Authentication authentication) {
        return authentication.getName();
    }

    @GetMapping
    public List<Recipe> getAllRecipes(
            Authentication authentication,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String category) {
        String email = currentEmail(authentication);
        if (search != null && !search.isBlank()) {
            return recipeService.searchByTitle(search, email);
        }
        if (category != null && !category.isBlank()) {
            return recipeService.getByCategory(category, email);
        }
        return recipeService.getAllRecipes(email);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Recipe> getRecipeById(Authentication authentication, @PathVariable Long id) {
        return recipeService.getRecipeById(id, currentEmail(authentication))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Recipe> createRecipe(Authentication authentication, @Valid @RequestBody Recipe recipe) {
        Recipe created = recipeService.createRecipe(recipe, currentEmail(authentication));
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Recipe> updateRecipe(Authentication authentication, @PathVariable Long id, @Valid @RequestBody Recipe recipe) {
        return recipeService.updateRecipe(id, recipe, currentEmail(authentication))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecipe(Authentication authentication, @PathVariable Long id) {
        boolean deleted = recipeService.deleteRecipe(id, currentEmail(authentication));
        return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
