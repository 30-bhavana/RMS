package com.recipeapp.service;

import com.recipeapp.model.Recipe;
import com.recipeapp.model.User;
import com.recipeapp.repository.RecipeRepository;
import com.recipeapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RecipeService {

    private final RecipeRepository recipeRepository;
    private final UserRepository userRepository;

    @Autowired
    public RecipeService(RecipeRepository recipeRepository, UserRepository userRepository) {
        this.recipeRepository = recipeRepository;
        this.userRepository = userRepository;
    }

    public List<Recipe> getAllRecipes(String ownerEmail) {
        return recipeRepository.findByOwnerEmail(ownerEmail);
    }

    public Optional<Recipe> getRecipeById(Long id, String ownerEmail) {
        return recipeRepository.findByIdAndOwnerEmail(id, ownerEmail);
    }

    public Recipe createRecipe(Recipe recipe, String ownerEmail) {
        User owner = userRepository.findByEmail(ownerEmail)
                .orElseThrow(() -> new IllegalStateException("Unknown user: " + ownerEmail));
        recipe.setOwner(owner);
        return recipeRepository.save(recipe);
    }

    public Optional<Recipe> updateRecipe(Long id, Recipe updated, String ownerEmail) {
        return recipeRepository.findByIdAndOwnerEmail(id, ownerEmail).map(existing -> {
            existing.setTitle(updated.getTitle());
            existing.setDescription(updated.getDescription());
            existing.setCategory(updated.getCategory());
            existing.setPrepTimeMinutes(updated.getPrepTimeMinutes());
            existing.setCookTimeMinutes(updated.getCookTimeMinutes());
            existing.setServings(updated.getServings());
            existing.setIngredients(updated.getIngredients());
            existing.setSteps(updated.getSteps());
            return recipeRepository.save(existing);
        });
    }

    public boolean deleteRecipe(Long id, String ownerEmail) {
        return recipeRepository.findByIdAndOwnerEmail(id, ownerEmail).map(recipe -> {
            recipeRepository.delete(recipe);
            return true;
        }).orElse(false);
    }

    public List<Recipe> searchByTitle(String title, String ownerEmail) {
        return recipeRepository.findByOwnerEmailAndTitleContainingIgnoreCase(ownerEmail, title);
    }

    public List<Recipe> getByCategory(String category, String ownerEmail) {
        return recipeRepository.findByOwnerEmailAndCategoryIgnoreCase(ownerEmail, category);
    }
}
